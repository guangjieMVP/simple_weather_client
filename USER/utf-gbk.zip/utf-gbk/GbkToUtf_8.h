#ifndef _GBKTOUTF_8_H_
#define _GBKTOUTF_8_H_

extern  int SwithToUtf_8(const unsigned char* pszBufIn, int nBufInLen, unsigned char* pszBufOut, int* pnBufOutLen);

#endif

