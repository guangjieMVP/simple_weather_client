#ifndef _UTF8TOGBK_H_
#define _UTF8TOGBK_H_

extern int SwitchToGbk(const unsigned char* pszBufIn, int nBufInLen, unsigned char* pszBufOut, int* pnBufOutLen);

#endif


